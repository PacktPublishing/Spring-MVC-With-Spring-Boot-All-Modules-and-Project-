drop table if exists students;

create table students
(
   ID integer not null,
   STUDENTNAME varchar(255) not null,
   AGE varchar(255) not null,
   DESCRIPTION varchar(255) not null,
   primary key(id)
);