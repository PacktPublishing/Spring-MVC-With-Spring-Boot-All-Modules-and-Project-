INSERT INTO Students (ID,STUDENTNAME,AGE,DESCRIPTION)
VALUES ('1','Sundar', '28', 'Description about the student!');

INSERT INTO Students (ID,STUDENTNAME,AGE,DESCRIPTION)
VALUES ('2','john', '38', 'Description about the student!');