package com.company.domain;

import java.util.List;

public class CustomTee {

	private String teeName;
	private List<String> userchoice;
	
	public CustomTee() {
	}
	
	public String getTeeName() {
		return teeName;
	}

	public void setTeeName(String teeName) {
		this.teeName = teeName;
	}

	public List<String> getUserchoice() {
		return userchoice;
	}

	public void setUserchoice(List<String> userchoice) {
		this.userchoice = userchoice;
	}

	@Override
	public String toString() {
		return "CustomTee [teeName=" + teeName + ", userchoice=" + userchoice + "]";
	}

	

}
