package com.company.controller;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.company.domain.CustomTee;

@Controller
@SessionAttributes("customTee")
@RequestMapping("/design")
public class DesignController {

	@GetMapping
	public String showMessage(Model model) {

		model.addAttribute("size", Arrays.asList("small", "medium", "large", "extra large"));
		model.addAttribute("sleeves", Arrays.asList("full", "half"));
		model.addAttribute("style", Arrays.asList("round neck", "collar"));
		
		model.addAttribute("customtee", new CustomTee());
		
		return "design";
	}
	
	@ModelAttribute("color")
	public List<String> color() {
		return Arrays.asList("red", "purple", "blue");
	}
	
	@ModelAttribute("customTee")
	public CustomTee customTee() {
		CustomTee ct = new CustomTee();
		ct.setTeeName("Test name");
		return ct;
	}
	
	@PostMapping
	public void showMessage(@ModelAttribute(binding=false) CustomTee customTee,ModelMap map, HttpServletResponse response) throws IOException {

		System.out.println("Custom Tee : "+customTee);
		response.getWriter().println("<h3>" + customTee.toString()+map.get("sleeves")+"</h3>");
		
	}
}
