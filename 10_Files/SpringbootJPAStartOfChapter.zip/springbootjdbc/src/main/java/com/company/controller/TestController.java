package com.company.controller;

import java.io.IOException;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.company.model.Student;
import com.company.model.StudentAddress;
import com.company.repository.StudentAddressRepository;
import com.company.repository.StudentRepository;

@Controller
public class TestController {

	@Autowired
	private StudentRepository studentRepository;
	
	@Autowired
	private StudentAddressRepository studentAddressRepository;

	@RequestMapping("/hello")
	public void showMessage(HttpServletResponse response) throws IOException {
		System.out.println("From controller..");
		
		studentRepository.deleteAll();
		studentAddressRepository.deleteAll();
		
		Student s = new Student("Sundar", 43, "Student Description..");
		
		StudentAddress sa = new StudentAddress("Address about the student!");
		
		s.setStudentAddress(sa);
		sa.setStudent(s);
		
		studentRepository.save(s);
		
		System.out.println(studentRepository.findAll());

	}
}
