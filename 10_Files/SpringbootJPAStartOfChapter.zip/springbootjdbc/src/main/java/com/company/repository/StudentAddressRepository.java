package com.company.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.company.model.StudentAddress;

@Repository
public interface StudentAddressRepository extends CrudRepository<StudentAddress, Long>{
		
}
