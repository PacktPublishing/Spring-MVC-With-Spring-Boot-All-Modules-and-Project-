package com.company.Controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import freemarker.template.utility.NullArgumentException;

@Controller
public class HelloWorldController {

	@RequestMapping("/Springboot/hello")
	public ModelAndView showMessage(
			@RequestParam(value = "name", required = false, defaultValue = "World") String name) {
		System.out.println("From controller..");
		if(true) {
			throw new NullPointerException();
		}
		ModelAndView mv = new ModelAndView("hello");
		mv.addObject("hello", "Hello");
		mv.addObject("name", name);
		return mv;
	}

}